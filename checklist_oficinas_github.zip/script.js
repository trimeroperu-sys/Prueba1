const itemsBase = [
  ["Recepción", "Escritorio", 1, "Bueno", ""],
  ["Recepción", "Silla", 1, "Bueno", ""],
  ["Recepción", "Computadora", 1, "Bueno", ""],
  ["Sala de reuniones", "Mesa", 1, "Bueno", ""],
  ["Sala de reuniones", "Sillas", 6, "Bueno", ""],
  ["Sala de reuniones", "Proyector / TV", 1, "Bueno", ""],
  ["Oficina administrativa", "Archivador", 1, "Bueno", ""],
  ["Oficina administrativa", "Impresora", 1, "Bueno", ""],
  ["Servicios higiénicos", "Lavatorio", 1, "Bueno", ""],
  ["Servicios higiénicos", "Dispensador de jabón", 1, "Bueno", ""],
  ["Kitchenette", "Microondas", 1, "Bueno", ""],
  ["Kitchenette", "Mesa / repostero", 1, "Bueno", ""]
];

document.addEventListener("DOMContentLoaded", () => {
  document.getElementById("fecha").valueAsDate = new Date();

  const guardado = localStorage.getItem("checklistOficinas");
  if (guardado) {
    cargarGuardado(JSON.parse(guardado));
  } else {
    itemsBase.forEach(item => agregarFila(item));
  }

  actualizarResumen();
});

function agregarFila(datos = ["", "", 1, "Bueno", ""]) {
  const tbody = document.getElementById("cuerpoTabla");
  const tr = document.createElement("tr");

  tr.innerHTML = `
    <td><input type="text" value="${datos[0]}" placeholder="Ambiente"></td>
    <td><input type="text" value="${datos[1]}" placeholder="Ítem"></td>
    <td><input type="number" min="0" value="${datos[2]}"></td>
    <td>
      <select onchange="actualizarResumen()">
        <option ${datos[3] === "Bueno" ? "selected" : ""}>Bueno</option>
        <option ${datos[3] === "Regular" ? "selected" : ""}>Regular</option>
        <option ${datos[3] === "Malo" ? "selected" : ""}>Malo</option>
        <option ${datos[3] === "Faltante" ? "selected" : ""}>Faltante</option>
        <option ${datos[3] === "No aplica" ? "selected" : ""}>No aplica</option>
      </select>
    </td>
    <td><textarea placeholder="Observación">${datos[4]}</textarea></td>
    <td><button class="danger" onclick="eliminarFila(this)">Eliminar</button></td>
  `;

  tbody.appendChild(tr);
  actualizarResumen();
}

function eliminarFila(btn) {
  btn.closest("tr").remove();
  actualizarResumen();
}

function obtenerDatos() {
  const filas = [...document.querySelectorAll("#cuerpoTabla tr")];

  return {
    fecha: document.getElementById("fecha").value,
    inspector: document.getElementById("inspector").value,
    sede: document.getElementById("sede").value,
    area: document.getElementById("area").value,
    items: filas.map(fila => {
      const campos = fila.querySelectorAll("input, select, textarea");
      return {
        ambiente: campos[0].value,
        item: campos[1].value,
        cantidad: campos[2].value,
        estado: campos[3].value,
        observacion: campos[4].value
      };
    })
  };
}

function guardar() {
  localStorage.setItem("checklistOficinas", JSON.stringify(obtenerDatos()));
  alert("Checklist guardado correctamente.");
}

function cargarGuardado(data) {
  document.getElementById("fecha").value = data.fecha || "";
  document.getElementById("inspector").value = data.inspector || "";
  document.getElementById("sede").value = data.sede || "";
  document.getElementById("area").value = data.area || "";

  document.getElementById("cuerpoTabla").innerHTML = "";
  data.items.forEach(x => agregarFila([
    x.ambiente,
    x.item,
    x.cantidad,
    x.estado,
    x.observacion
  ]));
}

function actualizarResumen() {
  const estados = [...document.querySelectorAll("#cuerpoTabla select")].map(x => x.value);

  document.getElementById("total").textContent = estados.length;
  document.getElementById("bueno").textContent = estados.filter(x => x === "Bueno").length;
  document.getElementById("regular").textContent = estados.filter(x => x === "Regular").length;
  document.getElementById("malo").textContent = estados.filter(x => x === "Malo").length;
  document.getElementById("faltante").textContent = estados.filter(x => x === "Faltante").length;
}

function descargarCSV() {
  const data = obtenerDatos();

  let csv = "Fecha,Inspector,Sede,Area,Ambiente,Item,Cantidad,Estado,Observacion\n";

  data.items.forEach(x => {
    csv += [
      data.fecha,
      data.inspector,
      data.sede,
      data.area,
      x.ambiente,
      x.item,
      x.cantidad,
      x.estado,
      x.observacion
    ].map(valor => `"${String(valor).replaceAll('"', '""')}"`).join(",") + "\n";
  });

  const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");

  a.href = url;
  a.download = "checklist_oficinas.csv";
  a.click();

  URL.revokeObjectURL(url);
}

function limpiar() {
  if (confirm("¿Seguro que deseas borrar todo el checklist?")) {
    localStorage.removeItem("checklistOficinas");
    document.getElementById("cuerpoTabla").innerHTML = "";
    itemsBase.forEach(item => agregarFila(item));
    actualizarResumen();
  }
}
