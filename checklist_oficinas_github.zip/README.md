# Checklist de Oficinas

Sistema web simple para registrar qué cosas hay en oficinas y en qué estado se encuentran.

## Archivos

- `index.html`
- `style.css`
- `script.js`

## Cómo usar

1. Subir los 3 archivos a GitHub.
2. Abrir `index.html`.
3. Completar el checklist.
4. Guardar avance.
5. Descargar reporte en CSV, que se puede abrir en Excel.

## Estados disponibles

- Bueno
- Regular
- Malo
- Faltante
- No aplica
